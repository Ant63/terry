(function ($) {
  $('img[usemap]').rwdImageMaps();
})(jQuery);;
